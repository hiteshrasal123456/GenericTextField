//
//  CSTextField.swift
//  HGenericTextfield
//
//  Created by Tejora on 24/04/20.
//  Copyright © 2020 Tejora. All rights reserved.
//
import Foundation
import UIKit
var appThemeColor = UIColorFromRGB(0x00adef)
var titleColor = UIColor.white
var blackColor = UIColorFromRGB(0x000000)
let grayColor = UIColor.lightGray
var blueColor = UIColorFromRGB(0x281976)
var yellowColor = UIColorFromRGB(0xf1c40f)
let borderLineColor = UIColorFromRGB(0xe1e1e1)
let lightGrayColor  = UIColor.init(red: 205.0/255.0, green: 205.0/255.0, blue: 205.0/255.0, alpha: 1.0)


/**** RGB Color ***/
public func UIColorFromRGB(_ rgbValue: UInt) -> UIColor {
    return UIColor(
        red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
        green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
        blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
        alpha: CGFloat(1.0)
    )
}

/**** Delgate Methods From Textfield ****/
protocol CSTextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool
    func textFieldDidBeginEditing(_ textField : UITextField)
    func textFieldDidEndEditing(_ textField : UITextField)
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool
}

class CSTextField: UITextField {
    
    public struct Constants {
        static let defaultiOSBorderColor = borderLineColor
    }
    
    var delegates: CSTextFieldDelegate?
    var imageView : UIImageView?
    var defaultImage : UIImage?
    var selectedImage : UIImage?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        configUI()
    }
    
    //MARK:- CUSTOM CONFIG UI
    private func configUI() {
        self.delegate = self
        self.layer.borderColor = Constants.defaultiOSBorderColor.cgColor
        self.placeHolderColor = grayColor
        self.textColor = blackColor
        self.layer.borderWidth = 1.0
    }
    
    override func canPerformAction(_ action: Selector, withSender sender: Any?) -> Bool {
        if action == #selector(UIResponderStandardEditActions.paste(_:)) {
                    return false
                }
                return super.canPerformAction(action, withSender: sender)
    }

    public func setLeftViewandRightView(_ size : CGFloat = 15) {
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: size, height: self.frame.size.height))
        leftView.contentMode = .left
        
        self.leftViewMode = .always
        self.leftView = leftView
        
        let rightView = UIView(frame: CGRect(x: 0, y: 0, width: size, height: self.frame.size.height))
        self.rightViewMode = .always
        self.rightView = rightView
    }
    
    public func setLeftViewandRightWithImageNameandSize(_ size : CGFloat = 15, _ defaultImageName : String) {
        
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: size, height: self.frame.size.height))
        leftView.contentMode = .left
        
        self.leftViewMode = .always
        self.leftView = leftView
        
        defaultImage = UIImage(named: defaultImageName)
        
        imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 45, height: self.frame.size.height))
        imageView?.contentMode = .center
        imageView?.tintColor = grayColor
        imageView?.image = defaultImage
        
        self.rightViewMode = .always
        self.rightView = imageView
    }
    
    public func setLeftViewandRightViewWithImagename(_ defaultImageName : String) {
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: 15, height: self.frame.size.height))
        leftView.contentMode = .left
        
        self.leftViewMode = .always
        self.leftView = leftView
        
        defaultImage = UIImage(named: defaultImageName)
        
        imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 45, height: self.frame.size.height))
        imageView?.contentMode = .center
        imageView?.tintColor = grayColor
        imageView?.image = defaultImage
        
        self.rightViewMode = .always
        self.rightView = imageView
    }
    
    public func setLeftViewandRightViewWithImageName(defaultImageName : String, selectedImageName : String?) {
        let leftView = UIView(frame: CGRect(x: 0, y: 0, width: 20, height: self.frame.size.height))
        leftView.contentMode = .left
        
        self.leftViewMode = .always
        self.leftView = leftView
        
        defaultImage = UIImage(named: defaultImageName)
        
        if let selectedImageName = selectedImageName {
            selectedImage = UIImage(named: selectedImageName)
        }
        
        imageView = UIImageView(frame: CGRect(x: 0, y: 5, width: 48, height: self.frame.size.height - 10))
        imageView?.contentMode = .scaleAspectFit
        imageView?.tintColor = grayColor
        imageView?.image = defaultImage
        
        self.rightViewMode = .always
        self.rightView = imageView
    }
}

//MARK:- EXTENSION METHODS
extension CSTextField : UITextFieldDelegate {
    
    //MARK:- TextField Delegate Methods
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if self.delegates != nil {
            return self.delegates?.textFieldShouldBeginEditing(textField) ?? true
        }
        
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if self.delegates != nil {
            self.delegates?.textFieldDidBeginEditing(textField)
        }
        
        if let imageView = imageView, let selectedImage = selectedImage {
            imageView.image = selectedImage
        }
        
        if selectedImage == nil {
            imageView?.tintColor = appThemeColor
        }
        
        self.placeHolderColor = appThemeColor
        self.layer.borderColor = appThemeColor.cgColor
        self.textColor = appThemeColor
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        if self.delegates != nil {
            return self.delegates?.textField(textField, shouldChangeCharactersIn: range, replacementString: string) ?? true
        }else {
            return true
        }
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        if self.delegates != nil {
            return self.delegates?.textFieldShouldEndEditing(textField) ?? true
        }
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if self.delegates != nil {
            self.delegates?.textFieldDidEndEditing(textField)
        }
 
        if let imageView = imageView, let defaultImage = defaultImage {
            imageView.image = defaultImage
        }
        
        if selectedImage == nil {
            imageView?.tintColor = grayColor
        }
        
        self.placeHolderColor = grayColor
        self.layer.borderColor = CSTextField.Constants.defaultiOSBorderColor.cgColor
        self.textColor = blackColor
    
    }
}

extension CSTextField {
    @IBInspectable var placeHolderColor: UIColor? {
        get {
            return self.placeHolderColor
        }
        set {
            self.attributedPlaceholder = NSAttributedString(string: self.placeholder ?? "",
                                                            attributes: [NSAttributedString.Key.foregroundColor: newValue!, NSAttributedString.Key.font: UIFont(name: "Arial", size: 16)!])
        }
    }
}
